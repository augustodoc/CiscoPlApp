from setuptools import setup


def readme():
    with open('README.rst') as f:
        return f.read()


setup(name='ciscoplapp',
      version='0.1',
      description='Scan Zeroconf web service in Raspberry Pi board with Cisco Pl-App',
      url='http://github.com/augustodoc/ciscoplapp',
      author='Augusto Costantini',
      author_email='augustocostantini@gmail.com',
      license='MIT',
      packages=['ciscoplapp'],
      scripts=['bin/ciscoplapp'],
      install_requires=['zeroconf3', 'psutil'],
      include_package_data=True,
      #data_files=[('icons', ['ciscoplapp/icons/start.gif', 'ciscoplapp/icons/scan.gif'])],
      zip_safe=False)
