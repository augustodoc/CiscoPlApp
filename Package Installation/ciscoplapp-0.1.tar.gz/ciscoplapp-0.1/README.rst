Cisco Pl-App
------------

To use, simply do::

    >>> import ciscoplapp
    >>> ciscoplapp.ScanPlApp()
