import datetime
import tkinter.ttk as ttk
import webbrowser
from tkinter import *
from tkinter import messagebox
from zeroconf import ZeroConf
import psutil
import os

PROGRAM_NAME = "ScanPL-APP"


class ScanPlApp:

    def __init__(self):
        self.root = Tk()
        self.root.geometry('600x400')
        self.root.title(PROGRAM_NAME)

        base_folder = os.path.dirname(__file__)
        image_path = os.path.join(base_folder, 'icons')

        img = PhotoImage(file=image_path + '/scan.gif')
        self.root.tk.call('wm', 'iconphoto', self.root, img)

        # self.new_file_icon = PhotoImage(file='icons/new_file.gif')
        # self.open_file_icon = PhotoImage(file='icons/open_file.gif')
        # self.save_file_icon = PhotoImage(file='icons/save.gif')
        # self.cut_icon = PhotoImage(file='icons/cut.gif')
        # self.copy_icon = PhotoImage(file='icons/copy.gif')
        # self.paste_icon = PhotoImage(file='icons/paste.gif')
        # self.undo_icon = PhotoImage(file='icons/undo.gif')
        # self.redo_icon = PhotoImage(file='icons/redo.gif')
        self.start_icon = PhotoImage(file=image_path + '/start.gif')
        # self.stop_icon = PhotoImage(file='icons/stop.gif')

        self.listbox = None
        self.treeview = None
        self.line_number_bar = None
        self.entry_search = None
        self.scale_request_count = None

        self.button_start = None
        self.button_stop = None

        self.running_scan = False

        self.analysis_index = 1
        self.scale_threshold = None
        self.threshold_tweet = 50
        self.tweet_request_count = 1000

        self.make_menu_bar()
        self.make_short_cut_and_line_bar()

        # self.headers = ['index', 'User Screen Name', 'User Created At', 'Account Reputation', 'Tweet Day', 'Tweets',
        #                 'Followers', 'Friends', 'Retweet Ratio', 'Mean URLs', 'Mean Length', 'Mean Time']
        # self.headers_type = ['int', 'string', 'date', 'float', 'float', 'int', 'int', 'int', 'float', 'float', 'float',
        #                      'float']

        self.headers = ['Host', 'Address', 'Port']
        self.headers_type = ['string', 'string', 'string', int]

        self.make_treeview_widget(self.headers)

        # self.button_stop.config(state=DISABLED)

        self.root.mainloop()

    def make_menu_bar(self):
        menu_bar = Menu(self.root)
        file_menu = Menu(menu_bar, tearoff=0)
        # file_menu.add_command(label='New', accelerator='Ctrl+N',
        #                       compound='left', image=self.new_file_icon, underline=0, command=self.insertTweetData)
        # file_menu.add_command(label='Open', accelerator='Ctrl+O',
        #                       compound='left', image=self.open_file_icon, underline=0)
        # file_menu.add_command(label='Save', accelerator='Ctrl+S',
        #                       compound='left', image=self.save_file_icon, underline=0)
        # file_menu.add_command(label='Save as', accelerator='Shift+Ctrl+S')
        # file_menu.add_separator()
        file_menu.add_command(label='Exit', accelerator='Alt+F4', command=self.exit)
        menu_bar.add_cascade(label='File', menu=file_menu)
        #
        # edit_menu = Menu(menu_bar, tearoff=0)
        # edit_menu.add_command(label='Undo', accelerator='Ctrl+Z',
        #                       compound='left', image=self.undo_icon)
        # edit_menu.add_command(label='Redo', accelerator='Ctrl+Y',
        #                       compound='left', image=self.redo_icon)
        # edit_menu.add_separator()
        # edit_menu.add_command(label='Cut', accelerator='Ctrl+X',
        #                       compound='left', image=self.cut_icon)
        # edit_menu.add_command(label='Copy', accelerator='Ctrl+C',
        #                       compound='left', image=self.copy_icon)
        # edit_menu.add_command(label='Paste', accelerator='Ctrl+V',
        #                       compound='left', image=self.paste_icon)
        # edit_menu.add_separator()
        # edit_menu.add_command(label='Find', underline=0, accelerator='Ctrl+F')
        # edit_menu.add_separator()
        # edit_menu.add_command(label='Select All', underline=7, accelerator='Ctrl+A')
        # menu_bar.add_cascade(label='Edit', menu=edit_menu)
        #
        # view_menu = Menu(menu_bar, tearoff=0)
        # View menu-items displays some variations
        # so we tackle view menu code to be entered here in a later section
        # menu_bar.add_cascade(label='View', menu=view_menu)

        about_menu = Menu(menu_bar, tearoff=0)
        about_menu.add_command(label='About', command=self.about)
        about_menu.add_command(label='Help', command=self.help)
        menu_bar.add_cascade(label='About', menu=about_menu)

        self.root.config(menu=menu_bar)  # menu ends

    def make_short_cut_and_line_bar(self):
        # add top shortcut bar & left line number bar
        shortcut_bar = Frame(self.root, height=25, background='light sea green')
        shortcut_bar.pack(expand='no', fill='x')

        self.button_start = Button(shortcut_bar, text='Start', image=self.start_icon, relief=FLAT, command=self.start)
        self.button_start.pack(side=LEFT, padx=2, pady=2)

        # self.button_stop = Button(shortcut_bar, text='Stop', image=self.stop_icon, relief=FLAT, command=self.stop)
        # self.button_stop.pack(side=LEFT, padx=2, pady=2)

        # self.entry_search = Entry(shortcut_bar)
        # self.entry_search.pack(side=RIGHT, padx=2, pady=2)
        # self.entry_search.bind("<Key>", self.get_query_list)

        # label_search = Label(shortcut_bar, text="Search:", background='light sea green')
        # label_search.pack(side=RIGHT, padx=2, pady=2)

        # self.scale_threshold = Scale(shortcut_bar, from_=1, to=600, orient=HORIZONTAL, length=300)
        # self.scale_threshold.pack(side=RIGHT, padx=2, pady=2)
        # self.scale_threshold.bind("<ButtonRelease-1>", self.get_threshold_tweet)
        # self.scale_threshold.set(self.threshold_tweet)

        # label_threshold = Label(shortcut_bar, text="Threshold:", background='light sea green')
        # label_threshold.pack(side=RIGHT, padx=2, pady=2)
        #
        # self.scale_request_count = Scale(shortcut_bar, from_=1, to=2000, orient=HORIZONTAL, length=300)
        # self.scale_request_count.pack(side=RIGHT, padx=2, pady=2)
        # #self.scale_request_count.bind("<ButtonRelease-1>", self.get_request_count_tweet)
        # self.scale_request_count.set(self.tweet_request_count)
        #
        # label_request = Label(shortcut_bar, text="Request count:", background='light sea green')
        # label_request.pack(side=RIGHT, padx=2, pady=2)
        #
        # self.line_number_bar = Text(self.root, width=4, padx=3, takefocus=0, border=0,
        #                             background='khaki', state='disabled', wrap='none')
        # self.line_number_bar.pack(side='left', fill='y')

    def make_text_widget_and_scroll_bar_widget(self):
        # add the main content Text widget and Scrollbar widget
        content_text = Text(self.root, wrap='word')
        content_text.pack(expand='yes', fill='both')
        scroll_bar = Scrollbar(content_text)
        content_text.configure(yscrollcommand=scroll_bar.set)
        scroll_bar.config(command=content_text.yview)
        scroll_bar.pack(side='right', fill='y')

    def make_listbox_widget_and_scroll_bar_widget(self):
        self.listbox = Listbox(self.root)
        self.listbox.pack(side=LEFT, fill=BOTH, expand=1)

        yScroll = Scrollbar(self.listbox, orient=VERTICAL)
        # yScroll.grid(row=0, column=1, sticky=N + S)

        xScroll = Scrollbar(self.listbox, orient=HORIZONTAL)
        # xScroll.grid(row=1, column=0, sticky=E + W)

        self.listbox.configure(xscrollcommand=xScroll.set, yscrollcommand=yScroll.set)
        # self.listbox = Listbox(self.root, xscrollcommand=xScroll.set, yscrollcommand=yScroll.set)
        # self.listbox = Listbox(self.root)

        yScroll.config(command=self.listbox.yview)
        xScroll.config(command=self.listbox.xview)
        yScroll.pack(side='right', fill='y')
        xScroll.pack(side='bottom', fill='x')

        # self.listbox.grid(row=0, column=0, sticky=N + S + E + W)

        for n in range(100):
            self.listbox.insert(END, "linea" + str(n))

        # self.listbox.pack(side=LEFT, fill=BOTH, expand=1)
        # xScroll['command'] = self.listbox.xview
        # yScroll['command'] = self.listbox.yview

    def start(self):

        if self.avahiRunning():

            self.treeview.delete(*self.treeview.get_children())  # operatore splat
            self.running_scan = True
            zc = ZeroConf()
            services = zc.search(name=None, type="_http._tcp", domain="local")
            # services = zc.search()

            # print(services, len(services))
            for s in services:
                service_key = s[0]
                item = service_key.split(':', 2)
                if len(item) == 2:
                    name = item[1]
                    host = item[0]
                    if name == 'cisco-pl-app':
                        pl_app_list = [host, services[s]['address'], services[s]['port']]
                        print(name, host, services[s]['address'], services[s]['port'])
                        self.treeviewInsert(pl_app_list)
            self.running_scan = False
        else:
            messagebox.showerror('Error', 'Avahi services not running ...\nInstall avahi-daemon package.')

    def make_treeview_widget(self, headers):

        self.treeview = ttk.Treeview(self.root, column=headers, show="headings")

        self.treeview.pack(side=LEFT, fill=BOTH, expand=1)

        yScroll = Scrollbar(self.treeview, orient=VERTICAL)

        xScroll = Scrollbar(self.treeview, orient=HORIZONTAL)

        self.treeview.configure(xscrollcommand=xScroll.set, yscrollcommand=yScroll.set)

        yScroll.config(command=self.treeview.yview)
        xScroll.config(command=self.treeview.xview)
        yScroll.pack(side='right', fill='y')
        xScroll.pack(side='bottom', fill='x')

        for h in headers:
            index = headers.index(h)
            if index > 0:
                self.treeview.heading(h, text=h.title(),
                                      command=lambda each_=index: self.treeview_sort_column(self.treeview, each_,
                                                                                            False))
                # self.treeview.heading(h, text=h.title(),command=self.sort_column)
            else:
                self.treeview.heading(h, text=h.title())

        self.treeview.bind('<Double-Button-1>', self.go_web_service)

    def go_web_service(self, event):

        item = self.treeview.selection()
        item_text = self.treeview.item(item, 'values')

        ip_address = item_text[1]
        port = item_text[2]
        print(item_text)
        webbrowser.open_new_tab('http://' + ip_address + ':' + port)

    def treeviewInsert(self, values_list):

        # l = []
        # l.append(self.analysis_index)

        # l = l + values_list
        # check class of value_list
        # and applicate an background color for identify the class

        if self.running_scan:
            self.treeview.insert('', 'end', values=values_list, tags="human")
            # self.analysis_index = self.analysis_index + 1

        # self.treeview.tag_configure('human',background='red')

    def get_key_int(self, item):
        return int(item[0])

    def get_key_float(self, item):
        return float(item[0])

    def get_key_string(self, item):
        return item[0].lower()

    def get_key_date(self, item):
        return datetime.datetime.strptime(item[0], "%d/%m/%Y")

    def treeview_sort_column(self, tv, col, reverse):
        l = [(tv.set(k, col), k) for k in tv.get_children('')]

        # print(self.headers_type[col])

        if self.headers_type[col] == 'int':
            l.sort(key=self.get_key_int, reverse=reverse)
        elif self.headers_type[col] == 'float':
            l.sort(key=self.get_key_float, reverse=reverse)
        elif self.headers_type[col] == 'string':
            l.sort(key=self.get_key_string, reverse=reverse)
        elif self.headers_type[col] == 'date':
            l.sort(key=self.get_key_date, reverse=reverse)

        # rearrange items in sorted positions
        for index, (val, k) in enumerate(l):
            tv.move(k, '', index)

        # reverse sort next time
        tv.heading(col, command=lambda: self.treeview_sort_column(tv, col, not reverse))

    # def insertTweetData(self):
    #     self.ta.collectData(['#trump'], insert_callback=self.treeviewInsert, print_flag=True)

    def about(self):
        messagebox.showinfo('About',
                            'Scan Raspberry Pi board with Cisco PL-App.\n\nAuthor: Augusto Costantini.\nEmail: augustocostantini@gmail.com.')

    def help(self):
        messagebox.showinfo('Help',
                            'Press Play button for scan.\n\nClick on item list for connnect a device with a default browser.')

    def exit(self):

        if self.running_scan:
            print("Analysis is active")
            messagebox.showwarning('Warning', 'Scan is still in progress. Wait for the action to terminate')
        else:
            self.root.quit()

    def avahiRunning(self):

        for proc in psutil.process_iter(attrs=['pid', 'name']):

            if proc.info['name'] == 'avahi-daemon':
                print(proc.info)
                return True
        return False


if __name__ == "__main__":
    ScanPlApp()
